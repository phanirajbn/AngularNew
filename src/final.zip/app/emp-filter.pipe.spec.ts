import { EmpFilterPipe } from './emp-filter.pipe';

describe('EmpFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new EmpFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
